﻿using System;
using System.Reflection;
using System.Linq;

namespace Reflection2
{
    //Fuente: https://johnlnelson.com/tag/type-getinterfaces/
    class Program
    {
        static void Main(string[] args)
        {
            Persona person = new Persona();
            Type personType = person.GetType();

            //get the PropertyInfo array for all properties
            PropertyInfo[] properties = personType.GetProperties();
            MethodInfo[] methods = personType.GetMethods();

            string sb = "";

            sb += ("================================================================\n");
            sb += (String.Format("Type Name: {0}\n", personType.Name));
            if(personType.IsClass)
                sb += "CLASS\n";
            sb += ("================================================================\n");

            //iterate the properties and write output
            foreach (PropertyInfo property in properties)
            {
                sb += ("----------------------------------------------------------------\n");
                sb += (String.Format("Property Name: {0}\n", property.Name));
                sb += ("----------------------------------------------------------------\n");

                sb += (String.Format("Property Type Name: {0}\n", property.PropertyType.Name));
                sb += (String.Format("Property Type FullName: {0}\n", property.PropertyType.FullName));

                sb += (String.Format("Can we read the property?: {0}\n", property.CanRead.ToString()));
                sb += (String.Format("Can we write the property?: {0}\n", property.CanWrite.ToString()));
            }
            sb += ("******************************\n");
            //iterate the methods and write output
            foreach (MethodInfo method in methods)
            {
               
                sb += (String.Format("Method info: {0}\n", personType.GetMethod(method.Name)));
                sb += ("***\n");

            }

            Console.WriteLine(sb);
        }
    }
}
